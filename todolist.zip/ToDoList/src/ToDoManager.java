import java.util.ArrayList;
import java.util.Scanner;

public class ToDoManager {
    private static ArrayList<String> currentList = new ArrayList<>();
    private static ArrayList<String> completedList = new ArrayList<>();
    private static ArrayList<String> dueDateList = new ArrayList<>();
    private static ArrayList<String> descList = new ArrayList<>();

    //main menu display
    public static int menu() {
    System.out.println();
    System.out.println("-----------------------------------");
    System.out.println("Main Menu");
    System.out.println("-----------------------------------");
    System.out.println("0. Exit the program");
    System.out.println("1. Display to-do list");
    System.out.println("2. Display description of to-do item");
    System.out.println("3. Add item to list");
    System.out.println("4. Remove item from list");
    System.out.println("5. Mark list item as completed");
    System.out.println("6. Show completed items");
    System.out.println("7. Edit an item");
    System.out.println();
    System.out.print("Enter choice: ");
    Scanner input = new Scanner(System.in);
    int choice = input.nextInt();
    return choice;
}
    //shows list in entirety
    public static void showList() {
        System.out.println();
        System.out.println("-----------------------------------");
        System.out.println("To-Do List        Due by");
        System.out.println("-----------------------------------");
        int number = 0;
        for (String item : currentList) {
            System.out.print(++number + " " + item + "  " + dueDateList.get(number-1) + "\n");
        }
    }
    //allows user to see the description they set for themselves
    public static void seeDescription() {
        Scanner input = new Scanner(System.in);

        System.out.println("Item Description");
        System.out.println("-----------------------------------");
        System.out.print("Which item number would you like to see?: ");
        int index = (input.nextInt() - 1);
        if((index)<0 || index>currentList.size()) {
            System.out.println("Wrong index number! Please enter in range of 1 to "+currentList.size());
        }else {
            System.out.println(descList.get(index));
            System.out.println("-----------------------------------");
        }
    }
    //adds an item to the 3 lists with your input
    public static void addItem() {
        System.out.println("Add Item");
        System.out.println("-----------------------------------");
        System.out.print("Enter an item: ");
        Scanner input = new Scanner(System.in);
        String item = input.nextLine();
        currentList.add(item);
        System.out.print("When is this item due? (DD MM yyyy): ");
        String dueDate = input.nextLine();
        dueDateList.add(dueDate);
        System.out.print("Add a description of the task: ");
        String desc = input.nextLine();
        descList.add(desc);
        showList();
    }
    //removes the item you specify
    public static void removeItem() {
        System.out.println("Remove Item");
        System.out.println("-----------------------------------");
        showList();
        Scanner input = new Scanner(System.in);
        System.out.print("Select the number you'd like to remove?: ");
        int index = (input.nextInt() - 1);
        if((index)<0 || index>currentList.size()) {
            System.out.println("Wrong index number! Please enter in range of 1 to "+currentList.size());
        }else {
            currentList.remove(index);
            dueDateList.remove(index);
            descList.remove(index);
        }
        System.out.println("-----------------------------------");
        showList();
    }
    //marks completion of an item
    public static void markCompleted() {
        System.out.println("Mark Item Complete");
        System.out.println("-----------------------------------");
        showList();
        Scanner input = new Scanner(System.in);
        System.out.print("Select the item number you'd like mark complete: ");
        int index = (input.nextInt() - 1);
        if((index)<0 || index>currentList.size()) {
            System.out.println("Wrong index number! Please enter in range of 1 to "+currentList.size());
        }else {
            completedList.add(currentList.get(index));
            currentList.remove(index);
            descList.remove(index);
        }
        System.out.println("-----------------------------------");
        showList();
    }
    //shows list items you marked as completed
    public static void showCompleted() {
        System.out.println();
        System.out.println("-----------------------------------");
        System.out.println("Completed List");
        System.out.println("-----------------------------------");
        int number = 0;
        for (String item : completedList) {
            System.out.println(++number + " " + item);
        }
        System.out.println("-----------------------------------");
    }
    //grabs list item from array list and allows user to set new name and time
    public static void editItem() {
        System.out.println("Edit Item");
        System.out.println("-----------------------------------");
        showList();
        Scanner input = new Scanner(System.in);
        System.out.print("Select the item number you'd like to edit: ");
        int index = Integer.parseInt(input.nextLine()) -1;
        if((index)<0 || index>currentList.size()) {
            System.out.println("Wrong index number! Please enter in range of 1 to "+currentList.size());
        }else {
            System.out.println(currentList.get(index));
            System.out.println("-----------------------------------");
            System.out.print("Enter the new item name: ");
            String item = input.nextLine();
            currentList.set(index, item);
            System.out.print("When is this item due? (DD MM yyyy): ");
            String dueDate = input.nextLine();
            dueDateList.set(index, dueDate);
        }
        System.out.println("-----------------------------------");
        showList();
    }
}
