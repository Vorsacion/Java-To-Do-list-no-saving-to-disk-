public class Main {
    public static void main(String[] args) {
        // Main switch logic to handle input and call various functions
        int menuItem = -1;
        try {
            while (menuItem != 0) {
                menuItem = ToDoManager.menu();
                switch (menuItem) {
                    case 1:
                        ToDoManager.showList();
                        break;
                    case 2:
                        ToDoManager.seeDescription();
                        break;
                    case 3:
                        ToDoManager.addItem();
                        break;
                    case 4:
                        ToDoManager.removeItem();
                        break;
                    case 5:
                        ToDoManager.markCompleted();
                        break;
                    case 6:
                        ToDoManager.showCompleted();
                        break;
                    case 7:
                        ToDoManager.editItem();
                        break;
                    case 0:
                        break;
                        // breaks out of the menu and ends the program
                    default:
                        System.out.println("Enter a valid option");
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
